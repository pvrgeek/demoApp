package com.pvr.demo.client.common.pvrresources;

/**
 * Created by palanivelrajan on 27-07-2014.
 */


import com.github.gwtbootstrap.client.ui.resources.Resources;
import com.google.gwt.resources.client.TextResource;

public interface ThemeResources extends Resources {

    @Source("com/pvr/demo/client/css/bootstrap.min.css")
    TextResource bootstrapCss();

}
