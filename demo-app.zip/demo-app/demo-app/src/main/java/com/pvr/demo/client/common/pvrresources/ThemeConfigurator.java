package com.pvr.demo.client.common.pvrresources;

/**
 * Created by palanivelrajan on 27-07-2014.
 *
 *
 */

import com.github.gwtbootstrap.client.ui.config.Configurator;
import com.github.gwtbootstrap.client.ui.resources.Resources;
import com.google.gwt.core.client.GWT;

public class ThemeConfigurator implements Configurator {

    public Resources getResources() {
        return GWT.create(ThemeResources.class);
    }

    public boolean hasResponsiveDesign() {
        return false;
    }
}


