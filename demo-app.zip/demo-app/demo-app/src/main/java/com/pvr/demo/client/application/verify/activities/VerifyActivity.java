package com.pvr.demo.client.application.verify.activities;

import com.google.gwt.activity.shared.AbstractActivity;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.google.inject.Inject;
import com.pvr.demo.client.application.verify.presenter.VerifyPresenter;
import com.pvr.demo.client.services.EmailBlackListCreateServiceAsync;
import com.pvr.demo.shared.model.EmailBlackListVO;
import com.smartgwt.client.util.SC;

/**
 * Created by palanivelrajan on 11-07-2014.
 * This class will use for the verify the  black list domains in to database from client side.
 */
public class VerifyActivity extends AbstractActivity {

    private final VerifyPresenter display;
    private EmailBlackListCreateServiceAsync rpcService;


    @Inject
    public VerifyActivity(VerifyPresenter display,EmailBlackListCreateServiceAsync rpcService) {
        this.display = display;
        this.rpcService=rpcService;
    }

    @Override
    public void start(AcceptsOneWidget acceptsOneWidget, EventBus eventBus) {
        bind();
        acceptsOneWidget.setWidget(display.asWidget());

    }

    private void bind() {
        createProcessing();

    }

    private void createProcessing() {

        display.getBtnSubmit().addClickHandler(new ClickHandler() {
            @Override
            public void onClick(ClickEvent clickEvent) {


                EmailBlackListVO vo = new EmailBlackListVO();
                String domainName = display.getTxtname().getValue();
                vo.setDomainName(domainName);
                rpcService.verify(vo, new AsyncCallback<EmailBlackListVO>() {
                    @Override
                    public void onFailure(Throwable throwable) {
                        SC.say("Email Black List domain verification failed");
                    }

                    @Override
                    public void onSuccess(EmailBlackListVO personVO) {

                          if(personVO != null) {
                              SC.say("Email Domain Available in the Black list");
                          } else{
                              SC.say("Email Domain is not Available in the Black list");
                          }

                    }
                });

            }
        }) ;


    }

}