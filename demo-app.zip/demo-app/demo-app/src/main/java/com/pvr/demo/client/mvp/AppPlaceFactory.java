package com.pvr.demo.client.mvp;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.pvr.demo.client.application.create.places.CreatePlace;
import com.pvr.demo.client.application.dashboard.places.DashboardPlace;
import com.pvr.demo.client.application.verify.places.VerifyPlace;

public class AppPlaceFactory {

    @Inject
    DashboardPlace.Tokenizer dashboardPlaceTokenizer;

    @Inject
    Provider<DashboardPlace> dashboardProvider;

    @Inject
    CreatePlace.Tokenizer createPlaceTokenizer;

    @Inject
    Provider<CreatePlace> createPlaceProvider;

    @Inject
    VerifyPlace.Tokenizer verifyPlaceTokenizer;

    @Inject
    Provider<VerifyPlace> verifyPlaceProvider;

    public DashboardPlace.Tokenizer getDashboardPlaceTokenizer() {
        return dashboardPlaceTokenizer;
    }

    public DashboardPlace getDashboardPlace() {
        return dashboardProvider.get();
    }

    public CreatePlace getCreatePlace() {
        return createPlaceProvider.get();
    }

    public VerifyPlace getVerifyPlace() {
        return verifyPlaceProvider.get();
    }

    public CreatePlace.Tokenizer getCreatePlaceTokenizer() {
        return createPlaceTokenizer;
    }

    public VerifyPlace.Tokenizer getVerifyPlaceTokenizer() {
        return verifyPlaceTokenizer;
    }
}
