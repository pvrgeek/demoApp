package com.pvr.demo.client.application.verify.presenter;

import com.google.gwt.user.client.ui.*;

/**
 * Created by palanivelrajan on 12-07-2014.
 */
public interface VerifyPresenter extends IsWidget {

    @Override
    Widget asWidget();


    DockLayoutPanel getDashField();

    Label getLblName();

    TextBox getTxtname();

    Button getBtnSubmit();
}
