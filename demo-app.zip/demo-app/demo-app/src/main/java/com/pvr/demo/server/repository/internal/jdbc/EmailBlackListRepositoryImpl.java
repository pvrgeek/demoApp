package com.pvr.demo.server.repository.internal.jdbc;

import com.pvr.demo.shared.model.EmailBlackListVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManagerFactory;

/**
 * Created by palanivelrajan on 09-08-2014.
 */
@Repository("emailBlackListRepositoryImpl")
public class EmailBlackListRepositoryImpl extends AbstractJpaRepository<Long,EmailBlackListVO> {

    @Autowired
    EntityManagerFactory entityManagerFactory;

    @PostConstruct
    public void init() {
        super.setEntityManagerFactory(entityManagerFactory);
    }
}
