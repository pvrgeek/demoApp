package com.pvr.demo.client.application.dashboard.ui;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.pvr.demo.client.application.dashboard.presenter.DashboardPresenter;

/**
 * Created by palanivelrajan on 11-07-2014.
 */
public class Dashboard  extends Composite implements DashboardPresenter{

    interface DashboardUiBinder extends UiBinder<Widget, Dashboard> {
    }

    private static DashboardUiBinder ourUiBinder = GWT.create(DashboardUiBinder.class);

    @Inject
    public Dashboard() {
       initWidget(ourUiBinder.createAndBindUi(this));

    }

    @UiField
    public DockLayoutPanel dashField;

    @Override
    public DockLayoutPanel getDashField() {
        return dashField;
    }
}