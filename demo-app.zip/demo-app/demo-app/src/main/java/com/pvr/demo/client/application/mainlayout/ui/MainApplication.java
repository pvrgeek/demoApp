package com.pvr.demo.client.application.mainlayout.ui;

import com.github.gwtbootstrap.client.ui.Button;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.place.shared.PlaceController;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.pvr.demo.client.application.create.places.CreatePlace;
import com.pvr.demo.client.application.mainlayout.presenter.MainApplicationPresenter;
import com.pvr.demo.client.application.verify.places.VerifyPlace;
import com.pvr.demo.client.common.pvrresources.PvrResources;


/**
 * Created by palanivelrajan on 11-07-2014.
 */
public class MainApplication extends Composite implements MainAppView  {


    private MainApplicationPresenter presenter;
    private final PlaceController placeController;
    private Provider<CreatePlace> gotoPlaceProvider;
    private Provider<VerifyPlace> gotoVerifyPlaceProvider;


    interface MainApplicationUiBinder extends UiBinder<Widget, MainApplication> {
    }

   // PvrResources resource = GWT.create(PvrResources.class);
    private static MainApplicationUiBinder ourUiBinder = GWT.create(MainApplicationUiBinder.class);

    @UiField
    SimplePanel detailArea;

    @UiField
    public Button btnCreate;

    @UiField
    public Button btnVerify;

    /*private  set(Widget widget){

        detailArea.clear();
        detailArea.add(widget);

    }*/






    public SimplePanel getContentPanel() {

        return detailArea;
    }

    @Inject
    public MainApplication(PvrResources resources, PlaceController placeController,Provider<CreatePlace> gotoPlaceProvider,Provider<VerifyPlace> gotoVerifyPlaceProvider) {
        this.placeController = placeController;
        resources.myStyle().ensureInjected();
        this.gotoPlaceProvider=gotoPlaceProvider;
        this.gotoVerifyPlaceProvider=gotoVerifyPlaceProvider;
       initWidget(ourUiBinder.createAndBindUi(this));


    }

    @Override
    public void setPresenter(MainApplicationPresenter presenter) {
        this.presenter= presenter;

    }

    @Override
    public Button getBtnCreate() {
        return btnCreate;
    }

    @Override
    public Button getBtnVerify() {
        return btnVerify;
    }

    @UiHandler("btnCreate")
    void HandleClickEvent(ClickEvent event){
        placeController.goTo(gotoPlaceProvider.get());
    }

    @UiHandler("btnVerify")
    void HandleVerifyClickEvent(ClickEvent event){
        placeController.goTo(gotoVerifyPlaceProvider.get());
    }

}