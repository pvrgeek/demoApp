package com.pvr.demo.server.repository;

import com.pvr.demo.shared.model.EmailBlackListVO;

/**
 * Created by palanivelrajan on 09-08-2014.
 */
public interface EmailBlackListRepository {
    void save(EmailBlackListVO vo);
}
