package com.pvr.demo.client.application.create.places;


import com.google.gwt.place.shared.PlaceTokenizer;
import com.google.gwt.place.shared.Prefix;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.pvr.demo.client.application.create.activities.CreateActivity;
import com.pvr.demo.client.mvp.ActivityPlace;

/**
 * Created by palanivelrajan on 11-07-2014.
 */
public class CreatePlace  extends ActivityPlace<CreateActivity> {

    @Inject
    public CreatePlace(CreateActivity activity) {
        super(activity);
    }

    @Prefix("create")
    public static class Tokenizer implements PlaceTokenizer<CreatePlace> {

        // Since the place is injectable, we'll let Gin do the construction.
        private final Provider<CreatePlace> placeProvider;

        @Inject
        public Tokenizer(Provider<CreatePlace> placeProvider) {
            this.placeProvider = placeProvider;
        }

        @Override
        public String getToken(CreatePlace place) {
            return place.getPlaceName();
        }

        @Override
        public CreatePlace getPlace(String token) {
            CreatePlace place = placeProvider.get();
            place.setPlaceName(token);
            return place;
        }

    }
}
