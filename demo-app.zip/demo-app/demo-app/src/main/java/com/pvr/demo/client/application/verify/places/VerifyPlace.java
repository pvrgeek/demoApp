package com.pvr.demo.client.application.verify.places;


import com.google.gwt.place.shared.PlaceTokenizer;
import com.google.gwt.place.shared.Prefix;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.pvr.demo.client.application.verify.activities.VerifyActivity;
import com.pvr.demo.client.mvp.ActivityPlace;

/**
 * Created by palanivelrajan on 11-07-2014.
 */
public class VerifyPlace  extends ActivityPlace<VerifyActivity> {

    @Inject
    public VerifyPlace(VerifyActivity activity) {
        super(activity);
    }

    @Prefix("verify")
    public static class Tokenizer implements PlaceTokenizer<VerifyPlace> {

        // Since the place is injectable, we'll let Gin do the construction.
        private final Provider<VerifyPlace> placeProvider;

        @Inject
        public Tokenizer(Provider<VerifyPlace> placeProvider) {
            this.placeProvider = placeProvider;
        }

        @Override
        public String getToken(VerifyPlace place) {
            return place.getPlaceName();
        }

        @Override
        public VerifyPlace getPlace(String token) {
            VerifyPlace place = placeProvider.get();
            place.setPlaceName(token);
            return place;
        }

    }
}
