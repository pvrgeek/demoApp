package com.pvr.demo.client.application.mainlayout.presenter;

import com.google.gwt.user.client.ui.IsWidget;
import com.google.gwt.user.client.ui.Widget;

/**
 * Created by palanivelrajan on 11-07-2014.
 */
public interface MainApplicationPresenter extends IsWidget {

    @Override
    Widget asWidget();
}
