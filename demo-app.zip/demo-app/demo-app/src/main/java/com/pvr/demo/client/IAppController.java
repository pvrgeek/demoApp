package com.pvr.demo.client;

import com.pvr.demo.client.application.mainlayout.presenter.MainApplicationPresenter;

/**
 * Created by palanivelrajan on 14-07-2014.
 */
public interface IAppController  extends MainApplicationPresenter {

    void start();

}
