package com.pvr.demo.client.services;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.pvr.demo.shared.model.EmailBlackListVO;

import java.util.List;

public interface EmailBlackListCreateServiceAsync {
    void add(EmailBlackListVO vo, AsyncCallback<EmailBlackListVO> async);

    void verify(EmailBlackListVO vo, AsyncCallback<EmailBlackListVO> asyncCallback);

    void retrieveAll(AsyncCallback<List<EmailBlackListVO>> asyncCallback);


    void delete(EmailBlackListVO domainName, AsyncCallback<EmailBlackListVO> asyncCallback);

}
