package com.pvr.demo.client;

import com.google.gwt.activity.shared.ActivityManager;
import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.place.shared.Place;
import com.google.gwt.place.shared.PlaceController;
import com.google.gwt.place.shared.PlaceHistoryHandler;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.pvr.demo.client.application.create.places.CreatePlace;
import com.pvr.demo.client.application.dashboard.places.DashboardPlace;
import com.pvr.demo.client.application.mainlayout.ui.MainApplication;
import com.pvr.demo.client.mvp.AppPlaceFactory;
import com.pvr.demo.client.mvp.AppPlaceHistoryMapper;

/**
 * Created by palanivelrajan on 13-07-2014.
 */
public class ApplicationController implements IAppController{

    private final PlaceController placeController;
    private final MainApplication appPanelView;
    private Place currentPlace;
    private final EventBus eventBus;
    private final ActivityMapper  activityMapper;
    private final AppPlaceFactory  factory;
    private Provider<CreatePlace> gotoPlaceProvider;


    @Inject
    public ApplicationController(PlaceController placeController, MainApplication appPanelView, EventBus eventBus, ActivityMapper activityMapper, AppPlaceFactory factory,Provider<CreatePlace> gotoPlaceProvider) {
        this.placeController = placeController;
        this.appPanelView = appPanelView;
        this.eventBus = eventBus;
        this.activityMapper = activityMapper;
        this.factory = factory;
        this.gotoPlaceProvider=gotoPlaceProvider;
    }


    @Override
    public void start() {

       // EventBus eventBus = injector.getEventBus();
        //PlaceController placeController = injector.getPlaceController();

        //ActivityMapper activityMapper = injector.getActivityMapper();
        ActivityManager activityManager = new ActivityManager(activityMapper, eventBus);
        //appWidget.add(new MainApplication());
        activityManager.setDisplay((com.google.gwt.user.client.ui.AcceptsOneWidget) appPanelView.getContentPanel());
        RootPanel.get().add(appPanelView,0,0);

        //AppPlaceFactory factory = injector.getAppPlaceFactory();
        DashboardPlace defaultPlace = factory.getDashboardPlace();

        //CreatePlace defaultPlace = factory.getCreatePlace();
        AppPlaceHistoryMapper historyMapper = GWT.create(AppPlaceHistoryMapper.class);
        historyMapper.setFactory(factory);

        PlaceHistoryHandler historyHandler = new PlaceHistoryHandler(historyMapper);
        historyHandler.register(placeController, eventBus, defaultPlace);



        historyHandler.handleCurrentHistory();

    }

    @Override
    public Widget asWidget() {

        return appPanelView;
    }





}
