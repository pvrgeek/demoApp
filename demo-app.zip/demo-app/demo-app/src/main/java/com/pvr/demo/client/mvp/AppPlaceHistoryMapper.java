package com.pvr.demo.client.mvp;

import com.google.gwt.place.shared.PlaceHistoryMapperWithFactory;

public interface AppPlaceHistoryMapper extends
        PlaceHistoryMapperWithFactory<AppPlaceFactory> {

	// empty

}
