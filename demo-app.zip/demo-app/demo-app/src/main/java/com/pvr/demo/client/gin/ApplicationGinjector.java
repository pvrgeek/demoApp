package com.pvr.demo.client.gin;


import com.google.gwt.inject.client.GinModules;
import com.google.gwt.inject.client.Ginjector;
import com.pvr.demo.client.ApplicationController;

@GinModules(ApplicationGinModule.class)
public interface ApplicationGinjector extends Ginjector {

	/*ActivityMapper getActivityMapper();
	
	PlaceController getPlaceController();
	
	EventBus getEventBus();
	
	AppPlaceFactory getAppPlaceFactory();*/

    ApplicationController getApplicationController();
	
}
