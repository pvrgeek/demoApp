package com.pvr.demo.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.SimplePanel;
import com.pvr.demo.client.gin.ApplicationGinjector;


public class DemoApp implements EntryPoint {

    private SimplePanel appWidget = new SimplePanel();

    private ApplicationGinjector injector = GWT.create(ApplicationGinjector.class);


  public void onModuleLoad() {

      ApplicationController controller = injector.getApplicationController();
      controller.start();


  }
}
