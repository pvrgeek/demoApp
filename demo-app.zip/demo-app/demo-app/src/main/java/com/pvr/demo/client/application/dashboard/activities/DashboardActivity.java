package com.pvr.demo.client.application.dashboard.activities;

import com.google.gwt.activity.shared.AbstractActivity;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.place.shared.PlaceController;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.google.inject.Inject;
import com.pvr.demo.client.application.dashboard.places.DashboardPlace;
import com.pvr.demo.client.application.dashboard.presenter.DashboardPresenter;
import com.pvr.demo.client.services.EmailBlackListCreateServiceAsync;
import com.pvr.demo.shared.model.EmailBlackListVO;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.ImgButton;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.HLayout;

import javax.inject.Provider;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by palanivelrajan on 11-07-2014.
 */
public class DashboardActivity extends AbstractActivity {

    private final DashboardPresenter display;
    private static ListGridRecord[] records;
    private EmailBlackListCreateServiceAsync rpcService;
    private Provider<DashboardPlace> gotoDashboard;
    private PlaceController controller;

    @Inject
    public DashboardActivity(DashboardPresenter display,EmailBlackListCreateServiceAsync rpcService,Provider<DashboardPlace> gotoDashboard,PlaceController controller) {
        this.display = display;
        this.rpcService=rpcService;
        this.gotoDashboard=gotoDashboard;
        this.controller=controller;
    }

    @Override
    public void start(AcceptsOneWidget acceptsOneWidget, EventBus eventBus) {
        bind();
        acceptsOneWidget.setWidget(display.asWidget());

    }

    private void bind() {

        preprocessing();

    }

    private void preprocessing() {

        rpcService.retrieveAll(new AsyncCallback<List<EmailBlackListVO>>(){


            @Override
            public void onFailure(Throwable throwable) {
                SC.say("retrieval of all domains failed");
            }

            @Override
            public void onSuccess(List<EmailBlackListVO> emailBlackListVOs) {

                final List<ListGridRecord> list = new ArrayList<>();
                ListGridRecord[] a = new  ListGridRecord[emailBlackListVOs.size()];
                for(int i=0;i<emailBlackListVOs.size();i++){
                    int id = emailBlackListVOs.get(i).getId();
                    String domain = emailBlackListVOs.get(i).getDomainName();
                    a[i] =  createRecord(domain,id) ;
                }

                final ListGrid countryGrid = new ListGrid() {
                    @Override
                    protected Canvas createRecordComponent(final ListGridRecord record, Integer colNum) {

                        String fieldName = this.getFieldName(colNum);

                        if (fieldName.equals("iconField")) {
                            HLayout recordCanvas = new HLayout(3);
                            recordCanvas.setHeight(22);
                            recordCanvas.setAlign(Alignment.CENTER);
                            ImgButton editImg = new ImgButton();
                            editImg.setShowDown(false);
                            editImg.setShowRollOver(false);
                            editImg.setLayoutAlign(Alignment.CENTER);
                            //editImg.setSrc("silk/comment_edit.png");
                            editImg.setPrompt("Edit Comments");
                            editImg.setHeight(16);
                            editImg.setWidth(16);
                            editImg.addClickHandler(new ClickHandler() {
                                public void onClick(ClickEvent event) {
                                    SC.say("Edit Comment Icon Clicked for country : " + record.getAttribute("domainName"));
                                }
                            });

                            ImgButton chartImg = new ImgButton();
                            chartImg.setShowDown(false);
                            chartImg.setShowRollOver(false);
                            chartImg.setAlign(Alignment.CENTER);
                            //chartImg.setSrc("silk/chart_bar.png");
                            chartImg.setPrompt("View Chart");
                            chartImg.setHeight(16);
                            chartImg.setWidth(16);
                            chartImg.addClickHandler(new ClickHandler() {
                                public void onClick(ClickEvent event) {
                                    SC.say("Chart Icon Clicked for country : " + record.getAttribute("countryName"));
                                }
                            });

                            recordCanvas.addMember(editImg);
                            recordCanvas.addMember(chartImg);
                            return recordCanvas;
                        } else if (fieldName.equals("buttonField")) {
                            IButton button = new IButton();
                            button.setHeight(18);
                            button.setWidth(65);
                            // button.setIcon("flags/16/" + record.getAttribute("countryCode") + ".png");
                            button.setTitle("Delete");
                            button.addClickHandler(new ClickHandler() {
                                public void onClick(ClickEvent event) {

                                    EmailBlackListVO vo  = new EmailBlackListVO();
                                    vo.setId(Integer.parseInt(record.getAttribute("id")));
                                    vo.setDomainName(record.getAttribute("domainName"));
                                    rpcService.delete(vo,new AsyncCallback<EmailBlackListVO>(){

                                        @Override
                                        public void onFailure(Throwable throwable) {
                                              SC.say("Delete Failed");
                                        }

                                        @Override
                                        public void onSuccess(EmailBlackListVO emailBlackListVO) {
                                            controller.goTo(gotoDashboard.get());
                                        }
                                    });
                                    //SC.say(record.getAttribute("domainName") + " Delete button clicked.");
                                }
                            });
                            return button;
                        } else {
                            return null;
                        }

                    }
                };
                countryGrid.setShowRecordComponents(true);
                countryGrid.setShowRecordComponentsByCell(true);
                countryGrid.setCanRemoveRecords(true);

                countryGrid.setWidth(1500);
                countryGrid.setHeight(800);
                countryGrid.setShowAllRecords(true);

                //ListGridField countryCodeField = new ListGridField("countryCode", "Flag", 40);
                //countryCodeField.setAlign(Alignment.CENTER);
                //countryCodeField.setType(ListGridFieldType.IMAGE);
                // countryCodeField.setImageURLPrefix("flags/16/");
                // countryCodeField.setImageURLSuffix(".png");

                ListGridField nameField = new ListGridField("domainName", "DomainName");

                ListGridField buttonField = new ListGridField("buttonField", "Delete");
                buttonField.setAlign(Alignment.CENTER);

      /*  ListGridField iconField = new ListGridField("iconField", "Comments/Stats");
        iconField.setWidth(100);*/

                countryGrid.setFields(nameField,buttonField);
                countryGrid.setCanResizeFields(true);
                ListGridRecord[] result =  list.toArray(new ListGridRecord[list.size()]);
                countryGrid.setData(a);

                //countryGrid.draw();
                display.getDashField().setSize("100%","100%");
                display.getDashField().addNorth(countryGrid,1000);


            }
        });

    }

    private ListGridRecord[] getRecords() {

        if (records == null) {
            records = getNewRecords();
        }
        return records;
    }

    private ListGridRecord[] getNewRecords() {
        final List<ListGridRecord> list = new ArrayList<>();
        ListGridRecord[] rec = new ListGridRecord[10];
        return rec;
    }

    private ListGridRecord createRecord(String domainName, int id) {

        ListGridRecord record = new ListGridRecord();
        record.setAttribute("domainName", domainName);
        record.setAttribute("id", id);
        return record;
    }
}
