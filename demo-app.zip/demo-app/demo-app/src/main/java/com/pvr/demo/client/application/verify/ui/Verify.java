package com.pvr.demo.client.application.verify.ui;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.*;
import com.google.inject.Inject;
import com.pvr.demo.client.application.verify.presenter.VerifyPresenter;

/**
 * Created by palanivelrajan on 24-10-2014.
 */
public class Verify extends Composite implements VerifyPresenter {

    interface VerifyUiBinder extends UiBinder<Widget, Verify> {
    }

    private static VerifyUiBinder ourUiBinder = GWT.create(VerifyUiBinder.class);

    @Inject
    public Verify() {
        initWidget(ourUiBinder.createAndBindUi(this));

    }

    @UiField
    public DockLayoutPanel dashField;

    @UiField
    public Label lblName;

    @UiField
    public TextBox txtname;

    @UiField
    public Button btnSubmit;





    @Override
    public DockLayoutPanel getDashField() {
        return dashField;
    }

    @Override
    public Label getLblName() {
        return lblName;
    }
    @Override
    public TextBox getTxtname() {
        return txtname;
    }
    @Override
    public Button getBtnSubmit() {
        return btnSubmit;
    }
}