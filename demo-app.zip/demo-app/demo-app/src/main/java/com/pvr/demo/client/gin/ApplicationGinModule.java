package com.pvr.demo.client.gin;

import com.google.gwt.activity.shared.ActivityMapper;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.event.shared.SimpleEventBus;
import com.google.gwt.inject.client.AbstractGinModule;
import com.google.gwt.place.shared.PlaceController;
import com.google.inject.Singleton;
import com.pvr.demo.client.ApplicationController;
import com.pvr.demo.client.IAppController;
import com.pvr.demo.client.application.create.presenter.CreatePresenter;
import com.pvr.demo.client.application.create.ui.Create;
import com.pvr.demo.client.application.dashboard.presenter.DashboardPresenter;
import com.pvr.demo.client.application.dashboard.ui.Dashboard;
import com.pvr.demo.client.application.mainlayout.ui.MainAppView;
import com.pvr.demo.client.application.mainlayout.ui.MainApplication;
import com.pvr.demo.client.application.verify.presenter.VerifyPresenter;
import com.pvr.demo.client.application.verify.ui.Verify;
import com.pvr.demo.client.mvp.AppActivityMapper;
import com.pvr.demo.client.mvp.AppPlaceFactory;

public class ApplicationGinModule extends AbstractGinModule {

	@Override
	protected void configure() {

		// bind the EventBus
		bind(EventBus.class).to(SimpleEventBus.class).in(Singleton.class);
		bind(PlaceController.class).to(InjectablePlaceController.class).in(Singleton.class);
		bind(AppPlaceFactory.class).in(Singleton.class);
        bind(IAppController.class).to(ApplicationController.class).in(Singleton.class);
		// bind the mapper
		bind(ActivityMapper.class).to(AppActivityMapper.class).in(Singleton.class);
		// bind the views
		bind(MainAppView.class).to(MainApplication.class);
        bind(DashboardPresenter.class).to(Dashboard.class);
        bind(CreatePresenter.class).to(Create.class);
        bind(VerifyPresenter.class).to(Verify.class);


	}
}
