package com.pvr.demo.client.common.pvrresources;

/**
 * Created by palanivelrajan on 29-07-2014.
 */
public interface CssResource extends com.google.gwt.resources.client.CssResource {
    String mainlayout();
    String headerLabel();
    String border();
    String paddingPanel();
    String moduleHeaderLabel();
}
