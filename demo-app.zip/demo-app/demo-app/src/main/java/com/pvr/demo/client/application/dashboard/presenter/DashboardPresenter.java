package com.pvr.demo.client.application.dashboard.presenter;

import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.IsWidget;
import com.google.gwt.user.client.ui.Widget;

/**
 * Created by palanivelrajan on 12-07-2014.
 */
public interface DashboardPresenter extends IsWidget {

    @Override
    Widget asWidget();


    DockLayoutPanel getDashField();
}
