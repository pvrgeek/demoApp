package com.pvr.demo.shared.model;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by palanivelrajan on 03-08-2014.
 */

@Entity
@Table(name="EMAILDOMAIN1")
public class EmailBlackListVO implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "DOMAINNAME", length = 100)
    private String domainName;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    @Override
    public String toString() {
        return "EmailBlackListVO{" +
                "id=" + id +
                ", domainName='" + domainName + '\'' +
                '}';
    }
}
