package com.pvr.demo.client.application.dashboard.places;


import com.google.gwt.place.shared.PlaceTokenizer;
import com.google.gwt.place.shared.Prefix;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.pvr.demo.client.application.dashboard.activities.DashboardActivity;
import com.pvr.demo.client.mvp.ActivityPlace;

/**
 * Created by palanivelrajan on 11-07-2014.
 */
public class DashboardPlace  extends ActivityPlace<DashboardActivity> {

    @Inject
    public DashboardPlace(DashboardActivity activity) {
        super(activity);
    }

    @Prefix("dashboard")
    public static class Tokenizer implements PlaceTokenizer<DashboardPlace> {

        // Since the place is injectable, we'll let Gin do the construction.
        private final Provider<DashboardPlace> placeProvider;

        @Inject
        public Tokenizer(Provider<DashboardPlace> placeProvider) {
            this.placeProvider = placeProvider;
        }

        @Override
        public String getToken(DashboardPlace place) {
            return place.getPlaceName();
        }

        @Override
        public DashboardPlace getPlace(String token) {
            DashboardPlace place = placeProvider.get();
            place.setPlaceName(token);
            return place;
        }

    }
}
