package com.pvr.demo.client.application.create.activities;

import com.google.gwt.activity.shared.AbstractActivity;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.place.shared.PlaceController;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.google.inject.Inject;
import com.pvr.demo.client.application.create.presenter.CreatePresenter;
import com.pvr.demo.client.application.dashboard.places.DashboardPlace;
import com.pvr.demo.client.services.EmailBlackListCreateServiceAsync;
import com.pvr.demo.shared.model.EmailBlackListVO;
import com.smartgwt.client.util.SC;

import javax.inject.Provider;

/**
 * Created by palanivelrajan on 11-07-2014.
 * This class will use for the inserting  black list domains in to database from client side.
 */
public class CreateActivity extends AbstractActivity {

    private final CreatePresenter display;
    private EmailBlackListCreateServiceAsync rpcService;
    private Provider<DashboardPlace> gotoDashboard;
    private PlaceController controller;


    @Inject
    public CreateActivity(CreatePresenter display,EmailBlackListCreateServiceAsync rpcService,Provider<DashboardPlace> gotoDashboard,PlaceController controller) {
        this.display = display;
        this.rpcService=rpcService;
        this.gotoDashboard=gotoDashboard;
        this.controller=controller;
    }

    @Override
    public void start(AcceptsOneWidget acceptsOneWidget, EventBus eventBus) {
        bind();
        acceptsOneWidget.setWidget(display.asWidget());

    }

    private void bind() {


        createProcessing();

    }

    private void createProcessing() {

        display.getBtnSubmit().addClickHandler(new ClickHandler() {
            @Override
            public void onClick(ClickEvent clickEvent) {


                EmailBlackListVO vo = new EmailBlackListVO();

                String domainName = display.getTxtname().getValue();
                vo.setDomainName(domainName);
                rpcService.add(vo, new AsyncCallback<EmailBlackListVO>() {
                    @Override
                    public void onFailure(Throwable throwable) {
                        SC.say("Email Black List domain added failed");
                    }

                    @Override
                    public void onSuccess(EmailBlackListVO personVO) {
                        controller.goTo(gotoDashboard.get());
                        SC.say("Email Black List domain added Sucessfully");
                    }
                });

            }
        }) ;


    }

}