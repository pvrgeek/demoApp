package com.pvr.demo.server.services;

import com.pvr.demo.client.services.EmailBlackListCreateService;
import com.pvr.demo.server.repository.internal.jdbc.EmailBlackListRepositoryImpl;
import com.pvr.demo.shared.model.EmailBlackListVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by palanivelrajan on 04-08-2014.
 */
@Service("emailBlackListService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class EmailDomainBlackListServiceImpl implements EmailBlackListCreateService {

    @PostConstruct
    public void init() throws Exception {

    }

    @PreDestroy
    public void destroy() {
    }

    @Autowired
    private EmailBlackListRepositoryImpl blackListRepository;


    @Override
    @Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
    public EmailBlackListVO add(EmailBlackListVO vo) {

        blackListRepository.persist(vo);
        return  vo;

    }

    @Override
    @Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
    public EmailBlackListVO verify(EmailBlackListVO vo) {
        List<EmailBlackListVO> list = new ArrayList<>();
        list = blackListRepository.findAll();
        for(EmailBlackListVO domain : list){
            if(vo != null && vo.getDomainName() != null){
                if(domain.getDomainName().equalsIgnoreCase(vo.getDomainName())) {
                    break;
                }else{
                    vo=null;
                }
            }

        }

        return vo;
    }

    @Override
    public List<EmailBlackListVO> retrieveAll() {
        List<EmailBlackListVO> list = new ArrayList<>();
        list = blackListRepository.findAll();
        return list;
    }

    @Override
    @Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
    public EmailBlackListVO delete(EmailBlackListVO domainName) {
        EmailBlackListVO vo = blackListRepository.merge(domainName);
        blackListRepository.remove(vo);
        return domainName;
    }
}
