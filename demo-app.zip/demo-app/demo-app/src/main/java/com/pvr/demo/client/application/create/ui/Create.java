package com.pvr.demo.client.application.create.ui;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.*;
import com.google.inject.Inject;
import com.pvr.demo.client.application.create.presenter.CreatePresenter;

/**
 * Created by palanivelrajan on 11-07-2014.
 */
public class Create  extends Composite implements CreatePresenter {

    interface CreateUiBinder extends UiBinder<Widget, Create> {
    }

    private static CreateUiBinder ourUiBinder = GWT.create(CreateUiBinder.class);

    @Inject
    public Create() {
       initWidget(ourUiBinder.createAndBindUi(this));

    }

    @UiField
    public DockLayoutPanel dashField;

    @UiField
    public Label lblName;

    @UiField
    public TextBox  txtname;

    @UiField
    public Button  btnSubmit;





    @Override
    public DockLayoutPanel getDashField() {
        return dashField;
    }

    @Override
    public Label getLblName() {
        return lblName;
    }
    @Override
    public TextBox getTxtname() {
        return txtname;
    }
    @Override
    public Button getBtnSubmit() {
        return btnSubmit;
    }
}