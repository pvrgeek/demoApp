package com.pvr.demo.client.services;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.pvr.demo.shared.model.EmailBlackListVO;

import java.util.List;

/**
 * Created by palanivelrajan on 04-08-2014.
 */
@RemoteServiceRelativePath("rpc/emailBlackListService")
public interface EmailBlackListCreateService extends RemoteService {

    EmailBlackListVO add(EmailBlackListVO vo);
    EmailBlackListVO verify(EmailBlackListVO vo);
    List<EmailBlackListVO> retrieveAll();
    EmailBlackListVO delete(EmailBlackListVO domainName);
}
