package com.pvr.demo.client.common.pvrresources;

import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

/**
 * Created by palanivelrajan on 27-07-2014.
 */
public interface PvrResources  extends ClientBundle {

    @Source("com/pvr/demo/client/images/DB1.jpg")
    ImageResource header();

    @Source("com/pvr/demo/client/css/myStyle.css")
    CssResource myStyle();


}
