package com.pvr.demo.client.application.mainlayout.ui;

import com.github.gwtbootstrap.client.ui.Button;
import com.google.gwt.user.client.ui.IsWidget;
import com.pvr.demo.client.application.mainlayout.presenter.MainApplicationPresenter;

/**
 * Created by palanivelrajan on 14-07-2014.
 */
public interface MainAppView extends IsWidget {

    void setPresenter(MainApplicationPresenter presenter);

    Button getBtnCreate();

    Button getBtnVerify();
}
